﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using Xunit;

namespace SpecFlowLinkGroupDemo.Steps
{
    [Binding]
    public class LinkFundSolutionsSteps
    {

        private IWebDriver driver;
        

        [When(@"I open the Found Solution page")]
        public void WhenIOpenTheFoundSolutionPage()
        {
            driver = new ChromeDriver(@"../../../Resources");
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://www.linkfundsolutions.co.uk/");
        }
        
        [Then(@"I can select the United Kingdom jurisdiction")]
        public void ThenICanSelectTheUnitedKingdomJurisdiction()
        {
            string UnitedName = driver.FindElement(By.XPath("//a[contains(text(),'United Kingdom')]")).Text;
            Thread.Sleep(2000);
            Assert.True(UnitedName.Contains("United Kingdom"), UnitedName + " doesn't contains 'United Kingdom'");
            driver.Quit();
        }

       
    }
}
