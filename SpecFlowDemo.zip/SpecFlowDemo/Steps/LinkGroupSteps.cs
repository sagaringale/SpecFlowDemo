﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using Xunit;

namespace SpecFlowLinkGroupDemo.Steps
{
    [Binding]
    public class LinkGroupSteps
    {
        private IWebDriver driver;
        private Actions actions => new Actions(driver);


        [When(@"I open the home page")]
        public void WhenIOpenTheHomePage()
        {
            driver = new ChromeDriver(@"../../../Resources");
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://www.linkgroup.eu/");
        }

        [Then(@"the page is displayed")]
        public void ThenThePageIsDisplayed()
        {
            string actualvalue = driver.FindElement(By.XPath("//header/div[1]/div[1]/div[3]/div[1]/nav[1]/div[1]/ul[1]/li[3]/a[1]")).Text;
            Thread.Sleep(2000);
            Assert.True(actualvalue.Contains("Careers"), actualvalue + " doesn't contains 'Careers'");
            driver.Close();

        }

        [Given(@"I have opened the home page")]
        public void GivenIHaveOpenedTheHomePage()
        {
            WhenIOpenTheHomePage();
        }

        [Given(@"I have agreed to the cookie policy")]
        public void GivenIHaveAgreedToTheCookiePolicy()
        {
            driver.FindElement(By.XPath("/html/body/div[2]/div/a[2]")).Click();
        }

        [When(@"I search for '(.*)'")]
        public void WhenISearchFor(string Text)
        {
            driver.FindElement(By.XPath("//header/div[1]/div[1]/div[2]/div[1]/nav[1]/div[1]/ul[1]/li[4]/a[1]/i[1]")).Click();
            IWebElement SearchText = driver.FindElement(By.XPath("//header/div[1]/div[1]/div[2]/div[1]/nav[1]/div[1]/ul[1]/li[4]/div[1]/form[1]/input[1]"));
            SearchText.SendKeys(Text);
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//button[contains(text(),'Search')]")).Click();
        }

        [Then(@"the search results are displayed")]
        public void ThenTheSearchResultsAreDisplayed()
        {
            Thread.Sleep(2000);
            string actualvalue = driver.FindElement(By.Id("SearchResults")).Text;
            Thread.Sleep(2000);
            Assert.True(actualvalue.Contains("Leeds"), actualvalue + " doesn't contains 'Leeds'");
            driver.Quit();
        }


    }  
}
