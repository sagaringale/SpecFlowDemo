SDET - Tech task
Name : Sagar Ingale
Date of completion : 24/02/2021

Tools: 
	Visual Studio 2019 with .Net Core 3.1
	Unit test framework: MsTest, XUnit
	SpecFlow v3.7.13
	Selenium WebDriver
	