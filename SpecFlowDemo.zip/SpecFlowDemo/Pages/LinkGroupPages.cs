﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpecFlowLinkGroupDemo.Pages
{
    public class LinkGroupPages
    {
        private IWebDriver driver;

        public LinkGroupPages(IWebDriver _driver)
        {
            this.driver = _driver;
        }
        public string getTitle()
        {
            return driver.Title;
        }

        public void PageIsDisplayed()
        {
            IWebElement PDisplayed = driver.FindElement(By.XPath("//span/p[2]/text()[1]"));
        }



    }
}
